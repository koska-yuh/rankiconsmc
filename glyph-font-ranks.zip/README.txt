Custom Minecraft glyphs (98 glyphs)
Made with the Minecraft Glyph Generator
https://nogard.dev/tools/minecraft-glyph-generator

INSTALL
Drop this .zip into your resourcepacks folder and enable it. Nothing needs unzipping.

USE
Paste the mapped Private Use Area characters (U+E200 to U+E2FF) anywhere
text appears: chat, signs, item and container names, titles, books.

The glyphs are added to the "ranks" font. Font providers merge across resource
packs, so shipping this one leaves normal text alone.
Reference it as minecraft:ranks in a text component's font field.

LICENCE
These glyphs are yours. The generator claims nothing over what you make with it -
use them freely, including commercially. A link back is appreciated, never required.
